﻿#include <iostream>

using namespace std;

#define VECTOR_SIZE 4

extern "C" float* GoASM(float*, float*, float*, int);

void cargarVector(float* vector) { 
	int index = 0;	// Cantidad fija de valores para el vector, uno extra para utilizar --max
	while (cin.good() && index < VECTOR_SIZE) {	// Mientras no hayan errores y hayan menos de VECTOR_SIZE datos
		cin >> vector[index];	// Leer el numero y guardar
		index++;
	}
}

void imprimirVector(float* vect) { // Imprime el vector resultado
	cout << endl << "Vector resultante: [";
	cout.precision(2);	// Asegurar precision de 2 decimales
	for (int index = 0; index < VECTOR_SIZE; index++) {
		cout << vect[index] << (index == 7 ? "]\n" : ", ");
	}
}

void iniciar(float* vec1, float* vec2, float* vec3) {	// Pide al usuario los valores para los vectores
	// Funciona como iniciador y reiniciador
	cout << "Por favor ingrese los 4 valores del vector 1:";
	cargarVector(vec1);

	cout << "Por favor ingrese los 4 valores del vector 2:";
	cargarVector(vec2);
}

int main() {
	cout << "Bienvenido al programa de prueba de operaciones de vectores con AVX." << endl;
	cout << "Los valores a ingresar pueden estar separados por espacios o por cambios de linea." << endl;
	

	float vec1[4] = { 0.0, 0.0, 0.0, 0.0};
	float vec2[4] = { 0.0, 0.0, 0.0, 0.0};	// Vector de flotantes 1, 2 y 3
	float vec3[4] = { 0.0, 0.0, 0.0, 0.0};

	iniciar(vec1, vec2, vec3);
	
	int opcion;	// Variable para la funcion de switch
	bool continuar = true;	// Booleano para salir del bucle
	while (continuar) {
		cout << endl << "¿Que operacion desea realizar entre los vectores?";
		cout << endl << "0 ---> Salir";
		cout << endl << "1 ---> Add";
		cout << endl << "2 ---> Sub";
		cout << endl << "3 ---> Mul";
		cout << endl << "4 ---> Div";
		cout << endl << "5 ---> Reiniciar";
		cout << endl;
		cin >> opcion;	// Lee la opcion dada por el usuario
		switch (opcion)	// Da a elegir que hacer con los vectores
		{
		case 0:
			cout << "Hasta luego." << endl;
			continuar = false;
			break;

		case 1:
			GoASM(vec1, vec2, vec3, 1);
			imprimirVector(vec3);
			break;

		case 2:
			GoASM(vec1, vec2, vec3, 2);
			imprimirVector(vec3);
			break;

		case 3:
			GoASM(vec1, vec2, vec3, 3);
			imprimirVector(vec3);
			break;

		case 4:
			GoASM(vec1, vec2, vec3, 4);
			imprimirVector(vec3);
			break;
		
		case 5:
			iniciar(vec1, vec2, vec3);
			break;
		}
	}
	
	return 0;
}

